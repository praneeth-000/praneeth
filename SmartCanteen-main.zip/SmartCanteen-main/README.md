# SmartCanteen

SmartCanteen is an online system for institutions offering canteen services, featuring standard and personalized options. It tracks users' eating patterns to provide tailored notifications and maintains a Khatta book for users. Admins receive order notifications, helping them identify popular dishes and consider replacing less favored ones.
